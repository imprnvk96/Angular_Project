
export class Student{
    constructor(public rollno:number, public name:string, public numberOfAttempts:number,
        public percentage:number, public subjectsLearning:string[]){

    }
}